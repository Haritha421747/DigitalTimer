#include "main.h"
#include "mode.h"
#include "clcd.h"
#include "i2c.h"
#include "ds1307.h"
#include "mkp_1.h"


unsigned char time[16]="               ",am[2][3]={"AM","PM"};
unsigned char clock_reg[3];
unsigned char key;
unsigned char calender_reg[4];
unsigned char date[16]="               ";
 unsigned char status = E_DEFSCREEN;
void init_config()
{
    //configue clcd and mkp switches
    GIE = 1;
    PEIE = 1;
    init_clcd();
	init_i2c();
	init_ds1307();
    init_mkp();
    
}

static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
//	time[8] = '\0';
}
static void get_date(void)
{
	calender_reg[0] = read_ds1307(YEAR_ADDR);
	calender_reg[1] = read_ds1307(MONTH_ADDR);
	calender_reg[2] = read_ds1307(DATE_ADDR);
	calender_reg[3] = read_ds1307(DAY_ADDR);

	date[0] = '0' + ((calender_reg[0] >> 4) & 0x0F);
	date[1] = '0' + (calender_reg[0] & 0x0F);
	date[2] = '-';
	date[3] = '0' + ((calender_reg[1] >> 4) & 0x0F);
	date[4] = '0' + (calender_reg[1] & 0x0F);
	date[5] = '-';
	date[6] = '0' + ((calender_reg[2] >> 4) & 0x0F);
	date[7] = '0' + (calender_reg[2] & 0x0F);
//	date[8] = '\0';
}

void main()
{
    //configuration
    init_config();
    //when power on or reset status will be DASHBOARD
   
    while(1)
    {
        get_time();
        get_date();
        key = read_matrix_keypad(STATE);
        switch(status)
        {
            case E_DEFSCREEN : //DASHBOARD operation
                                def_screen();
                                break;
            case E_MAINMENU  :
                                main_menu();
                                break;
            case E_SET_VIEW_EVENT :
                                set_view_event();
                                break;
            case E_SET_TIME_DATE :
                                set_time_date();
                                break;
            case  E_SET_TIME :
                                set_time();
                                break;
            case E_SET_DATE  :
                                set_date();
                                break;
                                    
        }
    }
    
    
}