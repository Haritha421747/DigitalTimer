#include "main.h"
#include "mode.h"
#include "clcd.h"
#include "i2c.h"
#include "ds1307.h"
#include "mkp_1.h"

extern unsigned char time[16],date[16],status,key,am[2][3];
int previous_sec=0,count=0,delay=0;
unsigned char star_flag=0,set_flag=1,mode_flag=0,am_index=0;
void def_screen(void)
{
    int sec=(time[6]-'0')*10+(time[7]-'0');
    if(sec!=previous_sec)
    {
        count++;
        previous_sec=sec;
    }
    if(count<=5)
    {
        
        clcd_print("DATE ",LINE1(0));
        clcd_print(date,LINE1(5));
        clcd_print("TIME ",LINE2(0));
        clcd_print(time,LINE2(5));
        clcd_print(am[am_index],LINE2(13));
    }
    else if(count<=7)
    {
      
        clcd_print("TIME ",LINE1(0));
        clcd_print(time,LINE1(5));
        clcd_print(am[am_index],LINE1(13));
        clcd_print("NO EVENT            ",LINE2(0));
        
    }
    else {
        count =0;
    }
    if(key == SW4)
    {
       
       clcd_print("                 ",LINE1(0));
       clcd_print("                 ",LINE2(0));
       status = E_MAINMENU;
       star_flag=0;
    }
    
}


 void main_menu()
 {
     if(key == SW1)
     {
         star_flag=0;
     }
     if(key == SW2)
     {
        star_flag=1;
     }
     if(star_flag == 0)
     {
         clcd_putch('>',LINE1(0));
         clcd_putch(' ',LINE2(0));
         clcd_print("SET/VIEW EVENT",LINE1(1));
         clcd_print("SET TIME/DATE",LINE2(1));
     }
     else if(star_flag == 1)
     {
         clcd_putch(' ',LINE1(0));
         clcd_putch('>',LINE2(0));
         clcd_print("SET/VIEW EVENT",LINE1(1));
         clcd_print("SET TIME/DATE",LINE2(1));
     }
     if(key == SW4)
     {
         clcd_print("                 ",LINE1(0));
         clcd_print("                 ",LINE2(0));
         status = star_flag+2;
         star_flag=0;
     }
     if(key == SW5)
     {
         clcd_print("                 ",LINE1(0));
         clcd_print("                 ",LINE2(0));
         status = E_DEFSCREEN;
     }
 }
 
 void set_view_event()
 {
     if(key == SW1)
     {
         star_flag=0;
     }
     if(key == SW2)
     {
        star_flag=1;
     }
     if(star_flag == 0)
     {
         clcd_putch('>',LINE1(0));
         clcd_putch(' ',LINE2(0));
         clcd_print("SET EVENT",LINE1(1));
         clcd_print("VIEW EVENT",LINE2(1));
     }
     else if(star_flag == 1)
     {
         clcd_putch(' ',LINE1(0));
         clcd_putch('>',LINE2(0));
         clcd_print("SET EVENT",LINE1(1));
         clcd_print("VIEW EVENT",LINE2(1));
     }
     if(key == SW4)
     {
         clcd_print("                 ",LINE1(0));
         clcd_print("                 ",LINE2(0));
         status = star_flag+4;
     }
     if(key == SW5)
     {
         clcd_print("                 ",LINE1(0));
         clcd_print("                 ",LINE2(0));
         status = E_MAINMENU;
     }
 }
 
 void set_time_date()
 {
     if(key == SW1)
     {
         star_flag=0;
     }
     if(key == SW2)
     {
        star_flag=1;
     }
     if(star_flag == 0)
     {
         clcd_putch('>',LINE1(0));
         clcd_putch(' ',LINE2(0));
         clcd_print("SET TIME",LINE1(1));
         clcd_print("SET DATE",LINE2(1));
     }
     else if(star_flag == 1)
     {
         clcd_putch(' ',LINE1(0));
         clcd_putch('>',LINE2(0));
         clcd_print("SET TIME",LINE1(1));
         clcd_print("SET DATE",LINE2(1));
     }
     if(key == SW4)
     {
         clcd_print("                 ",LINE1(0));
         clcd_print("                 ",LINE2(0));
         status = star_flag+6;
         set_flag=1;
         mode_flag=0;
         
     }
     if(key == SW5)
     {
         clcd_print("                 ",LINE1(0));
       clcd_print("                 ",LINE2(0));
       status = E_MAINMENU;
     }
 }
 
void set_time()
{
    //set time on RTC
    clcd_print("   HH:MM:SS:A/P      ", LINE1(0));
    static unsigned char hour,min,sec;
     unsigned char previous_index;
    //one time only store the data
    if(set_flag){
    //store the time only one time  
    hour=(time[0]-'0')*10+(time[1]-'0');
    min=(time[3]-'0')*10+(time[4]-'0');
    sec=(time[6]-'0')*10+(time[7]-'0');
    previous_index=am_index;
    set_flag=0;
    }
    //if sw2 pressed change field
    if(key == SW2)
    {
        if(mode_flag==3)
        {
            mode_flag=0;
        }
        else{
            mode_flag++; 
        }
    }
    //if sw1 pressed change the time on particular field
    if(key == SW1)
    {
        
        if(mode_flag == 0)
        {
           //change hour 
            hour++;
            if(hour == 13)
            {
                //if hour reached 24 reset to 0
                hour=1;
            }
        }
        else if(mode_flag == 1)
        {
            //change min
            min++;
            if(min == 60)
            {
                //if min reached 60 reset to 0
                min=0;
            }
        }
        else if(mode_flag == 2)
        {
            //change sec
            sec++;
            if(sec == 60)
            {
                //if sec reached 60 reset to 0
                sec = 0;
            }
        }
        else if(mode_flag == 3)
        {
            am_index=!am_index;
        }
    }
    if(mode_flag == 0){
        //blink hour field
        if(delay++ <= 100){
            clcd_putch(hour/10+'0', LINE2(3));
            clcd_putch(hour%10+'0', LINE2(4));
            clcd_putch(':', LINE2(5));
            clcd_putch(min/10+'0', LINE2(6));
            clcd_putch(min%10+'0', LINE2(7));
            clcd_putch(':', LINE2(8));
            clcd_putch(sec/10+'0', LINE2(9));
            clcd_putch(sec%10+'0', LINE2(10));
            clcd_print(am[am_index], LINE2(12));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(3));
            clcd_putch(-1, LINE2(4));
        
        }
        else
        {
            //reset delay
            delay = 0;
        }
            
    }
    if(mode_flag == 1){
        //blink min field
        if(delay++ <= 100){
            clcd_putch(hour/10+'0', LINE2(3));
            clcd_putch(hour%10+'0', LINE2(4));
            clcd_putch(':', LINE2(5));
            clcd_putch(min/10+'0', LINE2(6));
            clcd_putch(min%10+'0', LINE2(7));
            clcd_putch(':', LINE2(8));
            clcd_putch(sec/10+'0', LINE2(9));
            clcd_putch(sec%10+'0', LINE2(10));
            clcd_print(am[am_index], LINE2(12));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(6));
            clcd_putch(-1, LINE2(7));
        
        }
        else
        {
            delay = 0;
        }
            
    }
    if(mode_flag == 2){
        //blink sec field
        if(delay++ <= 100){
           clcd_putch(hour/10+'0', LINE2(3));
            clcd_putch(hour%10+'0', LINE2(4));
            clcd_putch(':', LINE2(5));
            clcd_putch(min/10+'0', LINE2(6));
            clcd_putch(min%10+'0', LINE2(7));
            clcd_putch(':', LINE2(8));
            clcd_putch(sec/10+'0', LINE2(9));
            clcd_putch(sec%10+'0', LINE2(10));
            clcd_print(am[am_index], LINE2(12));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(9));
            clcd_putch(-1, LINE2(10));
        
        }
        else
        {
            delay = 0;
        }
            
    }
    if(mode_flag == 3){
        //blink sec field
        if(delay++ <= 100){
           clcd_putch(hour/10+'0', LINE2(3));
            clcd_putch(hour%10+'0', LINE2(4));
            clcd_putch(':', LINE2(5));
            clcd_putch(min/10+'0', LINE2(6));
            clcd_putch(min%10+'0', LINE2(7));
            clcd_putch(':', LINE2(8));
            clcd_putch(sec/10+'0', LINE2(9));
            clcd_putch(sec%10+'0', LINE2(10));
            clcd_print(am[am_index], LINE2(12));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(12));
            clcd_putch(-1, LINE2(13));
        
        }
        else
        {
            delay = 0;
        }
            
    }
    
    if(key == SW4)
    {
        //if sw4 pressed save the data in RTC 
        
        write_ds1307(HOUR_ADDR, ((hour/10<<4) |( hour%10)));
        write_ds1307(MIN_ADDR, ((min/10<<4) |( min%10)));
        write_ds1307(SEC_ADDR, ((sec/10<<4) |( sec%10)));
        //status change to menu
        status = E_SET_TIME_DATE;
        clcd_print("                ", LINE1(0));
        clcd_print("                ", LINE2(0));
        
    }
    
    //if sw5 pressed exit
    if(key == SW5)
    {
        //status change to menu
        am_index = previous_index;
        status= E_SET_TIME_DATE;
        clcd_print("                ", LINE1(0));
        clcd_print("                ", LINE2(0));
    }
}

void set_date()
{
    //set time on RTC
    clcd_print("   YY-MM-DD    ", LINE1(0));
    static unsigned char year,mon,date1;
    //one time only store the data
    if(set_flag){
    //store the time only one time  
    year=(date[0]-'0')*10+(date[1]-'0');
    
    mon=(date[3]-'0')*10+(date[4]-'0');
    date1=(date[6]-'0')*10+(date[7]-'0');
    set_flag=0;
    }
    //if sw2 pressed change field
    if(key == SW2)
    {
        if(mode_flag==2)
        {
            mode_flag=0;
        }
        else{
            mode_flag++; 
        }
    }
    //if sw1 pressed change the time on particular field
    if(key == SW1)
    {
        
        if(mode_flag == 0)
        {
           //change hour 
            year++;
            if(year==100){
                year=0;
            }
            
        }
        else if(mode_flag == 1)
        {
            //change min
            mon++;
            if(mon == 13)
            {
                //if min reached 60 reset to 0
                mon=1;
            }
        }
        else if(mode_flag == 2)
        {
            //change sec
            date1++;
            if(date1 == 32)
            {
                //if sec reached 60 reset to 0
                date1 = 1;
            }
        }
    }
    if(mode_flag == 0){
        //blink hour field
        if(delay++ <= 100){
            clcd_putch((year/10)+'0', LINE2(3));
            clcd_putch(year%10+'0', LINE2(4));
            clcd_putch('-', LINE2(5));
            clcd_putch(mon/10+'0', LINE2(6));
            clcd_putch(mon%10+'0', LINE2(7));
            clcd_putch('-', LINE2(8));
            clcd_putch(date1/10+'0', LINE2(9));
            clcd_putch(date1%10+'0', LINE2(10));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(3));
            clcd_putch(-1, LINE2(4));
        
        }
        else
        {
            //reset delay
            delay = 0;
        }
            
    }
    if(mode_flag == 1){
        //blink min field
        if(delay++ <= 100){
            clcd_putch((year/10)+'0', LINE2(3));
            clcd_putch(year%10+'0', LINE2(4));
            clcd_putch('-', LINE2(5));
            clcd_putch(mon/10+'0', LINE2(6));
            clcd_putch(mon%10+'0', LINE2(7));
            clcd_putch('-', LINE2(8));
            clcd_putch(date1/10+'0', LINE2(9));
            clcd_putch(date1%10+'0', LINE2(10));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(6));
            clcd_putch(-1, LINE2(7));
        
        }
        else
        {
            delay = 0;
        }
            
    }
    if(mode_flag == 2){
        //blink sec field
        if(delay++ <= 100){
           clcd_putch((year/10)+'0', LINE2(3));
            clcd_putch(year%10+'0', LINE2(4));
            clcd_putch('-', LINE2(5));
            clcd_putch(mon/10+'0', LINE2(6));
            clcd_putch(mon%10+'0', LINE2(7));
            clcd_putch('-', LINE2(8));
            clcd_putch(date1/10+'0', LINE2(9));
            clcd_putch(date1%10+'0', LINE2(10));
        }
        else if(delay++ <= 300)
        {
            clcd_putch(-1, LINE2(9));
            clcd_putch(-1, LINE2(10));
        
        }
        else
        {
            delay = 0;
        }
            
    }
    
    if(key == SW4)
    {
        //if sw4 pressed save the data in RTC 
        
        write_ds1307(YEAR_ADDR, ((year/10<<4) |( year%10)));
        write_ds1307(MONTH_ADDR, ((mon/10<<4) |( mon%10)));
        write_ds1307(DATE_ADDR, ((date1/10<<4) |( date1%10)));
        //status change to menu
        status = E_SET_TIME_DATE;
        clcd_print("                ", LINE1(0));
        clcd_print("                ", LINE2(0));
        
    }
    
    //if sw5 pressed exit
    if(key == SW5)
    {
        //status change to menu
        status= E_SET_TIME_DATE;
        clcd_print("                ", LINE1(0));
        clcd_print("                ", LINE2(0));
    }
}
    