/* 
 * File:   main.h
 * Author: hp
 *
 * Created on 6 January, 2025, 11:43 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#include <xc.h>

#endif	/* MAIN_H */

