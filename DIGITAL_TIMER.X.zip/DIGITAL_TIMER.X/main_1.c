#include "main.h"
#include "mode.h"
#include "mkp.h"
#include "clcd.h"
#include "adc.h"
#include "uart_1.h"
#include "i2c.h"
#include "ds1307.h"
#include "exe.h"

unsigned char time[9];
unsigned char clock_reg[3];
unsigned char ev[][3]={"ON","GR","GN","G1","G2","G3","G4","G5"," C"};
unsigned char key;
 unsigned char status = E_DASHBOARD;
void init_config()
{
    //configue clcd and mkp switches
    GIE = 1;
    PEIE = 1;
    init_clcd();
    init_mkp();
    init_adc();
    init_uart();
	init_i2c();
	init_ds1307();
    
}

static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}

void main()
{
    //configuration
    init_config();
    //when power on or reset status will be DASHBOARD
   
    while(1)
    {
        get_time();
        key = read_matrix_keypad(STATE);
        switch(status)
        {
            case E_DASHBOARD : //DASHBOARD operation
                                dashboard();
                                break;
            case E_MENU      : //MENU
                                menu();
                                break;
            case E_VIEWLOG   : //VIEW LOG
                                view_log();
                                break;
            case E_DOWNLOADLOG : //DOWNLOAD LOG
                                download_log();
                                break;
            case E_CLEARLOG    : //CLEAR LOG
                                clear_log();
                                break;
            case E_SETTIMER    ://SET TIMER
                                set_timer();
                                break;
                                
                                    
        }
    }
    
    
}