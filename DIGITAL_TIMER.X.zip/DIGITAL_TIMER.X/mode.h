/* 
 * File:   mode.h
 * Author: hp
 *
 * Created on 6 January, 2025, 11:43 AM
 */

#ifndef MODE_H
#define	MODE_H

//status for mode
typedef enum{
    E_DEFSCREEN,
    E_MAINMENU,
    E_SET_VIEW_EVENT,
    E_SET_TIME_DATE,
    E_SET_EVENT,
    E_VIEW_EVENT,
    E_SET_TIME,
    E_SET_DATE
}status1;

void def_screen(void);

void main_menu();
 
void set_view_event();

void set_time_date();

void set_time();

void set_date();
#endif	/* MODE_H */

